﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ad.Controllers
{
   
    public class DefaultController : Controller
    {
        // GET: Default
 
         [Route("pizza/{id:int}")]//pizza/1
        public ActionResult Index()
        {
            return View();
        }

        [Route("pizza/{name:alpha}")]//pizza/veg

        public ActionResult test()
        {
            return View();
        }
    }
}