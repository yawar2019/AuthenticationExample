﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ClassLibrary1;
namespace ad.Controllers
{
    public class HomeController : Controller
    {
        public IEmployee _employee;

        public HomeController(IEmployee _emp)
        {
            _employee = _emp;
        }
        public ActionResult Index()
        {
            string Exam = _employee.FestivalWishing();
            ViewBag.Exam = Exam;
            return View();
        }

        public ActionResult About()
        {
            Employee obj = new Employee();
            obj.FestivalWishing();
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            Employee obj = new Employee();
            string s= obj.FestivalWishing();
            return View();
        }
    }
}